import java.util.*;

public class SchoolRosterTest
{
	public static void main(String[] args)
	{
		SchoolRoster roster = new SchoolRoster();
		
		System.out.println(roster);
		System.out.println();
		
		roster.computeGPA();
		
	    System.out.println(roster);
		System.out.println();
		
		ArrayList seniors = roster.fillSeniorList();
		
		System.out.println(seniors);
		System.out.println();
	}
}