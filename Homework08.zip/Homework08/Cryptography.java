public class Cryptography
{
    public static String encrypt(String message)
    {
        // YOUR CODE HERE
        
    }

    public static void main(String[] args)
    {
        String sentence = "This is a very big morning.";
        System.out.println(sentence);
        String codedText = encrypt(sentence);
        System.out.println(codedText);
    }
}