public class Gold extends Donation
{
    // YOUR CODE HERE
    
}