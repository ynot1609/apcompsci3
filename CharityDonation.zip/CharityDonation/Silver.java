public class Silver extends Donation
{
    // YOUR CODE HERE
    
}