import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class CharityJUnitTest
{
    Silver s = new Silver("John Wayne", 100.0);
    Gold g = new Gold("Jimmy Stewart", 500.0);
    Platinum p = new Platinum("Natalie Woods", 1000.0);
    
    @Test
    public void evaluateSilverClub()
    {
        String expected = "Silver";
        String actual = s.getClub();
        assertEquals("Failure: Strings not equal", expected, actual);
    }
    
    @Test
    public void evaluateSilverAmount()
    {
        double expected = 100.0;
        double actual = s.getAmount();
        assertEquals(expected, actual, 0.01);
    }

    @Test
    public void evaluateGoldClub()
    {
        String expected = "Gold";
        String actual = g.getClub();
        assertEquals("Failure: Strings not equal", expected, actual);
    }
    
    @Test
    public void evaluateGoldAmount()
    {
        double expected = 500.0;
        double actual = g.getAmount();
        assertEquals(expected, actual, 0.01);
    }

    @Test
    public void evaluatePlatinumClub()
    {
        String expected = "Platinum";
        String actual = p.getClub();
        assertEquals("Failure: Strings not equal", expected, actual);
    }
    
    @Test
    public void evaluatePlatinumAmount()
    {
        double expected = 1000.0;
        double actual = p.getAmount();
        assertEquals(expected, actual, 0.01);
    }
}
