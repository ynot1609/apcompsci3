public class Platinum extends Donation
{
    // YOUR CODE HERE
    
}