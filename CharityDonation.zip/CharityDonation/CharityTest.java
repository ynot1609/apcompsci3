public class CharityTest
{
    public static void main(String[] args)
    {
        Silver s = new Silver("John Wayne", 100.0);
        System.out.println(s);
        
        System.out.println();
        
        Gold g = new Gold("Jimmy Stewart", 500.0);
        System.out.println(g);
        
        System.out.println();
        
        Platinum p = new Platinum("Natalie Woods", 1000.0);
        System.out.println(p);
    }
}