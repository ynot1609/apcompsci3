public class Rectangle
{
    public static int calculateArea()
    {
        int length = 5;
        int width = 6;
        int area = 0;
        // YOUR CODE HERE
        
        return area;
    }
    
    public static void main(String[] args)
    {
        int result;
        result = calculateArea();
        System.out.println(result);    
    }
}