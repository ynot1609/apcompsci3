import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class RectangleJUnitTest
{
    @Test
    public void evaluatesExpression()
    {
        int expected = 30;
        int actual = Rectangle.calculateArea();
        assertEquals(expected, actual);
    }
}