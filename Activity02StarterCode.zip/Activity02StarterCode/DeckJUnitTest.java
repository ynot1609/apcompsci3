import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import org.junit.Test;

public class DeckJUnitTest
{
    String[] ranks = {"jack", "queen", "king"};
    String[] suits = {"blue", "red"};
    int[] pointValues = {11, 12, 13};
    Deck d = new Deck(ranks, suits, pointValues);
    
    @Test
    public void evaluateOneIsEmpty()
    {
        boolean actual = d.isEmpty();
        assertFalse(actual);
    }
    
    @Test
    public void evaluateTwoSize()
    {
        int expected = 6;
        int actual = d.size();
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateThreeDeal()
    {
        Card c = new Card("king", "red", 13);
        Card expected = c;
        Card actual = d.deal();
        assertEquals(expected.toString(), actual.toString());
    }
}
