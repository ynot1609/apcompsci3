public class TemperatureGrid
{
    private double[][] temps;

    public TemperatureGrid(double[][] tempArr)
    {
        temps = tempArr;
    }

    public double computeTemp(int row, int col)
    {
        // YOUR CODE HERE
        
    }

    public boolean updateAllTemps(double tolerance)
    {
        // YOUR CODE HERE
        
    }

    public String toString()
    {
        String result = "";
        for (double[] row : temps)
        {
            for (double item : row)
            {
                result += item + "\t";
            }
            result += "\n";
        }
        return result;
    }

    public double[][] getTemps()
    {
        return temps;
    }
}
