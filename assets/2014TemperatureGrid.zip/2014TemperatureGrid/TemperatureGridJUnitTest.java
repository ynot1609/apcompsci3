import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

public class TemperatureGridJUnitTest
{
    @Test
    public void thirdQuestionPartA()
    {
        double[][] weather = {  {95.5, 100.0, 100.0, 100.0, 100.0, 110.3},
                                {0.0, 50.0, 50.0, 50.0, 50.0, 0.0},
                                {0.0, 40.0, 40.0, 40.0, 40.0, 0.0},
                                {0.0, 20.0, 20.0, 20.0, 20.0, 0.0},
                                {0.0, 0.0, 0.0, 0.0, 0.0, 0.0} };
        TemperatureGrid tg = new TemperatureGrid(weather);

        assertEquals(37.5, tg.computeTemp(2, 3), 0.1);
        assertEquals(47.5, tg.computeTemp(1, 1), 0.1);
        assertEquals(100.0, tg.computeTemp(0, 2), 0.1);
        assertEquals(60.0, tg.computeTemp(1, 3), 0.1);
    }

    @Test
    public void thirdQuestionPartB()
    {
        double[][] weather = {  {95.5, 100.0, 100.0, 100.0, 100.0, 110.3},
                                {0.0, 50.0, 50.0, 50.0, 50.0, 0.0},
                                {0.0, 40.0, 40.0, 40.0, 40.0, 0.0},
                                {0.0, 20.0, 20.0, 20.0, 20.0, 0.0},
                                {0.0, 0.0, 0.0, 0.0, 0.0, 0.0} };
        TemperatureGrid tg = new TemperatureGrid(weather);

        assertFalse(tg.updateAllTemps(0.01));

        double[][] actual = tg.getTemps();
        double[][] expected = {  {95.5, 100.0, 100.0, 100.0, 100.0, 110.3},
                                {0.0, 47.5, 60.0, 60.0, 47.5, 0.0},
                                {0.0, 27.5, 37.5, 37.5, 27.5, 0.0},
                                {0.0, 15.0, 20.0, 20.0, 15.0, 0.0},
                                {0.0, 0.0, 0.0, 0.0, 0.0, 0.0} };
        assertArrayEquals(expected, actual);
    }
}
