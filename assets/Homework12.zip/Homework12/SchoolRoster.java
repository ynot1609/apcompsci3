import java.util.*;

public class SchoolRoster
{
    // instance variables
    private ArrayList<StudentInfo> roster;
    
    // constructors
    public SchoolRoster()
    {
        roster = new ArrayList<StudentInfo>();
    }
    
    public void addStudent(StudentInfo pupil)
    {
        roster.add(pupil);
    }
    
    public StudentInfo getStudent(int i)
    {
        return roster.get(i);
    }
    
    public void computeGPA()
    {
        // YOUR CODE HERE
        
    }
    
    public boolean isSenior(StudentInfo student)
    {
        // YOUR CODE HERE
        
    }
    
    public ArrayList<StudentInfo> fillSeniorList()
    {
        // YOUR CODE HERE
        
    }
    
    public String toString()
    {
        String result = "";
        for (StudentInfo item : roster)
        {
            result += item + "\n";
        }
        return result;
    }
}