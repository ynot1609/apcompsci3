//import java.util.*;

public class SchoolRosterTest
{
    public static void main(String[] args)
    {
        SchoolRoster group = new SchoolRoster();
        group.addStudent(new StudentInfo("King", 45, 171));
        group.addStudent(new StudentInfo("Norton", 128, 448));
        group.addStudent(new StudentInfo("Solo", 125, 350));
        group.addStudent(new StudentInfo("Kramden", 150, 150));
        
        System.out.println(group);
        group.computeGPA();
        
        System.out.println(group);
        System.out.println(group.fillSeniorList());
    }
}