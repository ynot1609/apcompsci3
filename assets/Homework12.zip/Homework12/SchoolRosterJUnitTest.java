import java.util.*;
import junit.framework.JUnit4TestAdapter;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class SchoolRosterJUnitTest
{
    private SchoolRoster group;
    
    @Before
    public void runBeforeEachTest()
    {
        group = new SchoolRoster();
        group.addStudent(new StudentInfo("King", 45, 171));
        group.addStudent(new StudentInfo("Norton", 128, 448));
        group.addStudent(new StudentInfo("Solo", 125, 350));
        group.addStudent(new StudentInfo("Kramden", 150, 150));
        group.computeGPA();
    }
    
    @After
    public void runAfterEachTest()
    {
        group = null;
    }
    
    @Test
    public void computeGPATestA()
    {
        double expected = 3.8;
        StudentInfo king = group.getStudent(0);
        double actual = king.getGPA();
        assertEquals(expected, actual, 0.01);
    }
    
    @Test
    public void computeGPATestB()
    {
        double expected = 3.5;
        StudentInfo norton = group.getStudent(1);
        double actual = norton.getGPA();
        assertEquals(expected, actual, 0.01);
    }
    
    @Test
    public void computeGPATestC()
    {
        double expected = 2.8;
        StudentInfo solo = group.getStudent(2);
        double actual = solo.getGPA();
        assertEquals(expected, actual, 0.01);
    }
    
    @Test
    public void computeGPATestD()
    {
        double expected = 1.0;
        StudentInfo kramden = group.getStudent(3);
        double actual = kramden.getGPA();
        assertEquals(expected, actual, 0.01);
    }
    
    @Test
    public void isSeniorTestA()
    {
        StudentInfo king = group.getStudent(0);
        assertFalse(group.isSenior(king));
    }
    
    @Test
    public void isSeniorTestB()
    {
        StudentInfo norton = group.getStudent(1);
        assertTrue(group.isSenior(norton));
    }
    
    @Test
    public void isSeniorTestC()
    {
        StudentInfo solo = group.getStudent(2);
        assertTrue(group.isSenior(solo));
    }
    
    @Test
    public void isSeniorTestD()
    {
        StudentInfo kramden = group.getStudent(3);
        assertFalse(group.isSenior(kramden));
    }
    
    @Test
    public void fillSeniorListTestA()
    {
        String expected = "Norton";
        group.computeGPA();
        ArrayList<StudentInfo> seniors = group.fillSeniorList();
        String actual = seniors.get(0).getName();
        assertEquals(expected, actual);
    }
    
    @Test
    public void fillSeniorListTestB()
    {
        String expected = "Solo";
        group.computeGPA();
        ArrayList<StudentInfo> seniors = group.fillSeniorList();
        String actual = seniors.get(1).getName();
        assertEquals(expected, actual);
    }
}