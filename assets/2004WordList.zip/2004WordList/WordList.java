import java.util.*;

public class WordList
{
    // instance variables
    private ArrayList<String> group;
    
    // constructors
    public WordList()
    {
        group = new ArrayList<String>();
    }
    
    // methods
    public void add(String word)
    {
        group.add(word);
    }
    
    public int numWordsOfLength(int len)
    {
        // YOUR CODE HERE
        
    }
    
    public void removeWordsOfLength(int len)
    {
        // YOUR CODE HERE
        
    }
    
    public String toString()
    {
        return group.toString();
    }
}