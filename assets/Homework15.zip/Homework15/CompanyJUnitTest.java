import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class CompanyJUnitTest
{
    Hourly jimmy = new Hourly("Jimmy Stewart", "232-12-8983", 7.25, 140);
    Hourly john = new Hourly("John Wayne", "423-23-1212", 8.50, 180);
    
    @Test
    public void evaluateOneSalary()
    {
        double expected = 1015.0;
        double actual = jimmy.getSalary();
        assertEquals(expected, actual, 0.01);
    }
    
    @Test
    public void evaluateTwoSalary()
    {
        double expected = 1615.0;
        double actual = john.getSalary();
        assertEquals(expected, actual, 0.01);
    }
}
    