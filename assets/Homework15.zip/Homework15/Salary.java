public class Salary extends Employee
{
    // instance variables
    private double yearlySalary;
    
    // constructors
    public Salary(String salName, String salNum, double salSalary)
    {
        super(salName, salNum);
        yearlySalary = salSalary;
    }
    
    public double getSalary()
    {
        return yearlySalary/12;
    }
}