public class Hourly extends Employee
{
    // YOUR CODE HERE
    
}