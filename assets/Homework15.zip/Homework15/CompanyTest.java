public class CompanyTest
{
    public static void main(String[] args)
    {
        Hourly jimmy = new Hourly("Jimmy Stewart", "232-12-8983", 7.25, 140);
        System.out.println(jimmy);
        
        System.out.println();
        
        Hourly john = new Hourly("John Wayne", "423-23-1212", 8.50, 180);
        System.out.println(john);
    }
}