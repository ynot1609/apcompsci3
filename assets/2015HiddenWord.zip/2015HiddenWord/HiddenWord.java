public class HiddenWord
{
    // YOUR CODE HERE
    
}
