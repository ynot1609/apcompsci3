public class SkyView
{
    private double[][] view;

    public SkyView(int numRows, int numCols, double[] scanned)
    {
        // YOUR CODE HERE
        
    }

    public double getAverage(int startRow, int endRow, int startCol, int endCol)
    {
        // YOUR CODE HERE
        
    }

    public String toString()
    {
        String result = "";
        for (double[] row : view)
        {
            for (double item : row)
            {
                result += item + " ";
            }
            result += "\n";
        }
        return result;
    }
}
