public class Hailstone
{
    public static int sequenceSteps(int n)
    {
        int steps = 0;
        // YOUR CODE HERE
        
        
        return steps;
    }
    
    public static void main(String[] args)
    {
        System.out.println("Sequence n = 387, steps = " + sequenceSteps(387));
        System.out.println("Sequence n = 7316, steps = " + sequenceSteps(7316));
        System.out.println("Sequence n = 553, steps = " + sequenceSteps(553));
        System.out.println("Sequence n = 1725, steps = " + sequenceSteps(1725));
        System.out.println("Sequence n = 8174, steps = " + sequenceSteps(8174));
        System.out.println("Sequence n = 4948, steps = " + sequenceSteps(4948));
        System.out.println("Sequence n = 2218, steps = " + sequenceSteps(2218));
        System.out.println("Sequence n = 490, steps = " + sequenceSteps(490));
        System.out.println("Sequence n = 6567, steps = " + sequenceSteps(6567));
        System.out.println("Sequence n = 1512, steps = " + sequenceSteps(1512));
    }
}