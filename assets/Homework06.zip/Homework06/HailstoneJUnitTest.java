import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class HailstoneJUnitTest
{
    @Test
    public void testOne()
    {
        int expected = 120;
        int actual = Hailstone.sequenceSteps(387);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testTwo()
    {
        int expected = 132;
        int actual = Hailstone.sequenceSteps(7316);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testThree()
    {
        int expected = 136;
        int actual = Hailstone.sequenceSteps(553);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testFour()
    {
        int expected = 42;
        int actual = Hailstone.sequenceSteps(1725);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testFive()
    {
        int expected = 158;
        int actual = Hailstone.sequenceSteps(8174);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testSix()
    {
        int expected = 28;
        int actual = Hailstone.sequenceSteps(4948);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testSeven()
    {
        int expected = 19;
        int actual = Hailstone.sequenceSteps(2218);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testEight()
    {
        int expected = 22;
        int actual = Hailstone.sequenceSteps(490);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testNine()
    {
        int expected = 75;
        int actual = Hailstone.sequenceSteps(6567);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testTen()
    {
        int expected = 109;
        int actual = Hailstone.sequenceSteps(1512);
        assertEquals(expected, actual);
    }
}
