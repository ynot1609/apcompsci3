public interface Employee
{
    int getID();
    int getAge();
    int getYearsOnJob();
    double getSalary();
}
