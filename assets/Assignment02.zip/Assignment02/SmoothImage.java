public class SmoothImage
{
    public static int[][] blurring(int[][] pic)
    {
        // YOUR CODE HERE
        
    }
    
    
    public static void main(String[] args)
    {
        int[][] image  = {{0,0,0,0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0,0,0,0},
                          {0,0,5,5,5,5,5,5,5,5,0,0},
                          {0,0,5,5,5,5,5,5,5,5,0,0},
                          {0,0,5,5,5,5,5,5,5,5,0,0},
                          {0,0,5,5,5,5,5,5,5,5,0,0},
                          {0,0,5,5,5,5,5,5,5,5,0,0},
                          {0,0,5,5,5,5,5,5,5,5,0,0},
                          {0,0,5,5,5,5,5,5,5,5,0,0},
                          {0,0,5,5,5,5,5,5,5,5,0,0},
                          {0,0,0,0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0,0,0,0}};
        int[][] smooth;
        
        // compute the smoothed value for each cell of the array
        smooth = blurring(image);
        
        // display the array image
        System.out.print("image:\n");
        for (int[] row : image)
        {
            for (int item : row)
            {
                System.out.print(item + " ");
            }
            System.out.println();
        }
        System.out.println();
        
        // display the array smooth
        System.out.print("smooth:\n");
        for (int[] row : smooth)
        {
            for (int item : row)
            {
                System.out.print(item + " ");
            }
            System.out.println();
        }

    }
}