import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class CryptographyJUnitTest
{
    @Test
    public void evaluateEncryptOne()
    {
        String expected = "This is a agxzrery big ssadorning.";
        String actual = Cryptography.encrypt("This is a very big morning.");
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateEncryptTwo()
    {
        String expected = "A agxzrictory ssadagnificent!";
        String actual = Cryptography.encrypt("A victory magnificent!");
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateEncryptThree()
    {
        String expected = "A agxzralid ssadethod.";
        String actual = Cryptography.encrypt("A valid method.");
        assertEquals(expected, actual);
    }
}
