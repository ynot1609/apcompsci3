public class CellPhoneTest
{
    public static void main(String[] args)
    {
        TextMessage t0 = new TextMessage("Order some pizza", "Allen Preston");
        TextMessage t1 = new TextMessage("Send for coffee", "Larry Craig");
        TextMessage t2 = new TextMessage("Meet me for lunch", "Tristan Ruben");
        TextMessage t3 = new TextMessage("Gym session tonight", "Mallory Jones");
        TextMessage t4 = new TextMessage("Bring math textbook", "Zoe Smith");
        TextMessage t5 = new TextMessage("Buy concert tickets", "Deandra Miller");
        
        CellPhone lenovo = new CellPhone();
        lenovo.insertTextMessage(0, t0);
        lenovo.insertTextMessage(1, t1);
        lenovo.insertTextMessage(2, t2);
        lenovo.insertTextMessage(3, t3);
        lenovo.insertTextMessage(4, t4);
        lenovo.insertTextMessage(5, t5);
        
        System.out.println("Quantity of messages: " + lenovo.messageCount() + "\n");
        System.out.println("Message at index 2: " + lenovo.getMessage(2) + "\n");
        System.out.println("Search for Deandra Miller: " + lenovo.searchSender("Deandra Miller"));
        System.out.println("Search for Max Riley: " + lenovo.searchSender("Max Riley") + "\n");
        
        System.out.println(lenovo);
        
        System.out.println("Deleting message at index 4.\n");
        lenovo.deleteMessage(4);
        
        System.out.println(lenovo);
        
        System.out.println("Clearing all messages.\n");
        lenovo.clearMessages();
        
        System.out.println(lenovo);
    }
}
