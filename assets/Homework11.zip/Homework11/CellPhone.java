public class CellPhone
{
    // instance variables
    private TextMessage[] inbox;
    
    // constructors
    public CellPhone()
    {
        inbox = new TextMessage[8];
    }
    
    // YOUR CODE HERE
    
    
    
    public String toString()
    {
        String result = "";
        for (int i = 0; i < inbox.length; i++)
        {
            if (inbox[i] != null)
            {
                result += "Position: " + i + "\n";
                result += "Message: " + inbox[i].getMessage() + "\n";
                result += "Sender: " + inbox[i].getSender() + "\n\n";
            }
        }
        return result;
    }
    
    public TextMessage getTM(int i)
    {
        return inbox[i];
    }
    
    public TextMessage[] getInbox()
    {
        return inbox;
    }
}
