public class TextMessage
{
    // instance variables
    private String message;
    private String sender;
    
    public TextMessage(String m, String s)
    {
        message = m;
        sender = s;
    }
    
    public String getMessage()
    {
        return message;
    }
    
    public String getSender()
    {
        return sender;
    }
}