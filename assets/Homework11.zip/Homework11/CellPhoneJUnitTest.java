import junit.framework.JUnit4TestAdapter;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertNull;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CellPhoneJUnitTest
{
    private CellPhone lenovo;
    private CellPhone galaxy;
    
    @Before
    public void runBeforeEachTest()
    {
        TextMessage t0 = new TextMessage("Order some pizza", "Allen Preston");
        TextMessage t1 = new TextMessage("Send for coffee", "Larry Craig");
        TextMessage t2 = new TextMessage("Meet me for lunch", "Tristan Ruben");
        TextMessage t3 = new TextMessage("Gym session tonight", "Mallory Jones");
        TextMessage t4 = new TextMessage("Bring math textbook", "Zoe Smith");
        TextMessage t5 = new TextMessage("Buy concert tickets", "Deandra Miller");
        
        lenovo = new CellPhone();
        lenovo.insertTextMessage(0, t0);
        lenovo.insertTextMessage(1, t1);
        lenovo.insertTextMessage(2, t2);
        lenovo.insertTextMessage(3, t3);
        lenovo.insertTextMessage(4, t4);
        lenovo.insertTextMessage(5, t5);
        
        TextMessage m0 = new TextMessage("Time for dinner", "Kiara Curtis");
        TextMessage m1 = new TextMessage("Pick up milk", "Casey Colton");
        TextMessage m2 = new TextMessage("Buy some bread", "Beth Raymond");
        
        galaxy = new CellPhone();
        galaxy.insertTextMessage(0, m0);
        galaxy.insertTextMessage(1, m1);
        galaxy.insertTextMessage(2, m2);
    }
    
    @After
    public void runAfterEachTest()
    {
        lenovo = null;
        galaxy = null;
    }
    
    @Test
    public void insertTextMessageTest()
    {
        lenovo.insertTextMessage(6, new TextMessage("Good night", "Ed Troy"));
        String expected = "Good night";
        String actual = lenovo.getMessage(6);
        assertEquals(expected, actual);
    }
    
    @Test
    public void messageCountTestA()
    {
        int expected = 6;
        int actual = lenovo.messageCount();
        assertEquals(expected, actual);
    }
    
    @Test
    public void messageCountTestB()
    {
        int expected = 3;
        int actual = galaxy.messageCount();
        assertEquals(expected, actual);
    }
    
    @Test
    public void getMessageTestA()
    {
        String expected = "Order some pizza";
        String actual = lenovo.getMessage(0);
        assertEquals(expected, actual);
    }
    
    @Test
    public void getMessageTestB()
    {
        String expected = "Pick up milk";
        String actual = galaxy.getMessage(1);
        assertEquals(expected, actual);
    }
    
    @Test
    public void searchSenderTestA()
    {
        boolean expected = true;
        boolean actual = lenovo.searchSender("Larry Craig");
        assertEquals(expected, actual);
    }
    
    @Test
    public void searchSenderTestB()
    {
        boolean expected = false;
        boolean actual = lenovo.searchSender("Clay Grant");
        assertEquals(expected, actual);
    }
    
    @Test
    public void deleteMessageTest()
    {
        lenovo.deleteMessage(4);
        assertNull(lenovo.getTM(4));
    }
    
    @Test
    public void clearMessagesTest()
    {
        lenovo.clearMessages();
        TextMessage[] expected = {null, null, null, null, null, null, null, null};
        TextMessage[] actual = lenovo.getInbox();
        assertArrayEquals(expected, actual);
    }
}
