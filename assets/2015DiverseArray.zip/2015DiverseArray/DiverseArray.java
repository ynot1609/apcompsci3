public class DiverseArray
{
    public static int arraySum(int[] arr)
    {
        // YOUR CODE HERE
        
    }
    
    public static int[] rowSums(int[][] arr2D)
    {
        // YOUR CODE HERE
        
    }
    
    public static boolean isDiverse(int[][] arr2D)
    {
        // YOUR CODE HERE
        
    }
}
