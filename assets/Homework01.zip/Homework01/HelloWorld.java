public class HelloWorld
{
    public static String displayMessage()
    {
        // Use the assignment operator to assign the message "hello world"
        // to the String variable "greetings".
        // YOUR CODE HERE
        
        
        return greetings;
    }
    
    public static void main(String[] args)
    {
        String result = displayMessage();
        System.out.println(result);
    }
}
