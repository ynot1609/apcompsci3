import static org.junit.Assert.assertArrayEquals;
import org.junit.Test;

public class SmoothSignalJUnitTest
{
    @Test
    public void evaluateSmoothOne()
    {
        int[] expected = {3, 3, 4, 5, 6, 7, 6, 6, 5, 4, 4, 4};
        int[] waveform = {1, 5, 4, 5, 7, 6, 8, 6, 5, 4, 5, 4};
        int[] actual = SmoothSignal.levelling(waveform);
        assertArrayEquals(expected, actual);
    }
    
    @Test
    public void evaluateSmoothTwo()
    {
        int[] expected = {33,38,48,63,58,63,68,72,72,46,44,50,61,69,66,72};
        int[] waveform = {29,38,47,59,84,32,75,98,43,75,20,39,91,54,63,82};
        int[] actual = SmoothSignal.levelling(waveform);
        assertArrayEquals(expected, actual);
    }

    @Test
    public void evaluateSmoothThree()
    {
        int[] expected = {571,580,415,561,691,691,655,617,582,529,482,553,433,397,578,819,916};
        int[] waveform = {817,326,598,321,765,987,321,659,873,216,498,732,429,138,625,973,859};
        int[] actual = SmoothSignal.levelling(waveform);
        assertArrayEquals(expected, actual);
    }
}
