import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class AcidLevelsJUnitTest
{
    @Test
    public void evaluateAverageOne()
    {
        double expected = 6.091666666666668;
        double ph[] = {5.6, 6.2, 6.0, 5.5, 5.7, 6.1, 7.4, 5.5, 5.5, 6.3, 6.4, 4.0, 6.9};
        double actual = AcidLevels.accurateAverage(ph);
        assertEquals(expected, actual, 0.01);
    }
    
    @Test
    public void evaluateAverageTwo()
    {
        double expected = 61.98181818181819;
        double ph[] = {23.9,84.7,53.9,48.5,98.5,12.8,73.9,87.5,34.9,80.2,32.7,63.1};
        double actual = AcidLevels.accurateAverage(ph);
        assertEquals(expected, actual, 0.01);
    }
    
    @Test
    public void evaluateAverageThree()
    {
        double expected = 530.2666666666668;
        double ph[] = {293.4,572.9,438.7,737.5,390.8,874.3,298.7,982.6,493.8,672.3};
        double actual = AcidLevels.accurateAverage(ph);
        assertEquals(expected, actual, 0.01);
    }
}