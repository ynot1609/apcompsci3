public class SecondsYear
{
    public static double calculateSeconds()
    {
        double seconds = 0;
        
        // YOUR CODE HERE
        
        
        return seconds;
    }
    
    public static void main(String[] args)
    {
        double result = calculateSeconds();
        System.out.println("Seconds in a year: " + result);
    }
}
