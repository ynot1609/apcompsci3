import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class SecondsYearJUnitTest
{
    @Test
    public void evaluatesExpression()
    {
        double expected = 31536000;
        double actual = SecondsYear.calculateSeconds();
        assertEquals(expected, actual, 0.1);
    }
}
