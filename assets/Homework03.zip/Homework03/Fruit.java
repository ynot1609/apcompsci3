public class Fruit
{
    public static int[] countingFruit()
    {
        // YOUR CODE HERE
        
        
        
        
        
        
        
        int[] basket = new int[6];
        basket[0] = apples;
        basket[1] = oranges;
        basket[2] = peaches;
        basket[3] = grapes;
        basket[4] = bananas;
        basket[5] = pineapples;
        return basket;
    }
    
    public static void main(String[] args)
    {
        int[] result = countingFruit();
        for (int item : result)
        {
            System.out.println(item);
        }
        
    }
}