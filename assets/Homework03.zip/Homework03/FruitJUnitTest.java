import static org.junit.Assert.assertArrayEquals;
import org.junit.Test;

public class FruitJUnitTest
{
    @Test
    public void evaluatesExpression()
    {
        int[] expected = {35, 22, 18, 10, 8, 5};
        int[] actual = Fruit.countingFruit();
        assertArrayEquals("failure: int arrays not same", expected, actual);
    }
}