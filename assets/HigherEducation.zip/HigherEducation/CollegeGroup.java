import java.util.*;

public class CollegeGroup
{
    // instance variables
    private ArrayList<College> myColleges;
    
    // constructors
    public CollegeGroup()
    {
        myColleges = new ArrayList<College>();
    }
    
    public void updateTuition(String collegeName, int newTuition)
    {
        // YOUR CODE HERE
        
    }
    
    public ArrayList<College> getCollegeList(String region, int low, int high)
    {
        // YOUR CODE HERE
        
    }
    
    public void addCollege(College c)
    {
        myColleges.add(c);
    }
    
    public ArrayList<College> getColleges()
    {
        return myColleges;
    }
}