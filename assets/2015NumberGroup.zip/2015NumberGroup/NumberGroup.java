public interface NumberGroup
{
    boolean contains(int num);
}