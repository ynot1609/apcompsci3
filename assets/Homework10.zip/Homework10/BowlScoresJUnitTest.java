import junit.framework.JUnit4TestAdapter;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertArrayEquals;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BowlScoresJUnitTest
{
    private BowlScores frame;
    private BowlScores session;
    
    @Before
    public void runBeforeEachTest()
    {
        frame = new BowlScores("Chuck", 4);
        frame.setGameScore(0, 178);
        frame.setGameScore(1, 192);
        frame.setGameScore(2, 185);
        frame.setGameScore(3, 183);
        
        session = new BowlScores("Dave", 2);
        session.setGameScore(0, 126);
        session.setGameScore(1, 159);
    }
    
    @After
    public void runAfterEachTest()
    {
        frame = null;
        session = null;
    }
    
    @Test
    public void getNameTest()
    {
        String expected = "Chuck";
        String actual = frame.getName();
        assertEquals(expected, actual);
    }
    
    @Test
    public void getNumGamesTest()
    {
        int expected = 4;
        int actual = frame.getNumGames();
        assertEquals(expected, actual);
    }
    
    @Test
    public void getBowlScoresTest()
    {
        int[] expected = {178, 192, 185, 183};
        int[] actual = frame.getBowlScores();
        assertArrayEquals(expected, actual);
    }
    
    @Test
    public void getScoreTest()
    {
        int expected = 178;
        int actual = frame.getScore(0);
        assertEquals(expected, actual);
    }
    
    @Test
    public void getTotalTest()
    {
        int expected = 738;
        int actual = frame.getTotal();
        assertEquals(expected, actual);
    }
    
    @Test
    public void getAverageTest()
    {
        double expected = 184.5;
        double actual = frame.getAverage();
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void setNameTest()
    {
        frame.setName("Bradley");
        String expected = "Bradley";
        String actual = frame.getName();
        assertEquals(expected, actual);
    }
    
    @Test
    public void setGameScoreTest()
    {
        frame.setGameScore(0, 199);
        int expected = 199;
        int actual = frame.getScore(0);
        assertEquals(expected, actual);
    }
    
    @Test
    public void getTotalTestA()
    {
        int expected = 285;
        int actual = session.getTotal();
        assertEquals(expected, actual);
    }
    
    @Test
    public void getAverageTestA()
    {
        double expected = 142.5;
        double actual = session.getAverage();
        assertEquals(expected, actual, 0.1);
    }
}