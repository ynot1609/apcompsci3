public class BowlScores
{
    // YOUR CODE HERE
    
    
    // toString() method
    public String toString()
    {
        String result = "";
        result += "Bowler: " + name + "\n";
        for (int i = 0; i < gameScores.length; i++)
        {
            result += "Game " + i + ": " + gameScores[i] + "\n";
        }
        result += "Total: " + getTotal() + "\n";
        result += "Average: " + getAverage() + "\n";
        return result;
    }
}
