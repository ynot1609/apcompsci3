public class BowlScoresTest
{
    public static void main(String[] args)
    {
        BowlScores frame = new BowlScores("Chuck", 4);
        frame.setGameScore(0, 178);
        frame.setGameScore(1, 192);
        frame.setGameScore(2, 185);
        frame.setGameScore(3, 183);
        System.out.println(frame);
    }
}