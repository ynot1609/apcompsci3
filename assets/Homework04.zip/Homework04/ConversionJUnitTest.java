import static org.junit.Assert.assertArrayEquals;
import org.junit.Test;

public class ConversionJUnitTest
{
    @Test
    public void evaluatesExpression()
    {
        double[] expected = {2.54, 0.9144, 1.609, 0.3937, 1.094, 0.6214, 9.464E12};
        double[] actual = Conversion.unitConversions();
        assertArrayEquals(expected, actual, 0.0001);
    }
}