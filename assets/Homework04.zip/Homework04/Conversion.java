public class Conversion
{
    public static double[] unitConversions()
    {
        // YOUR CODE HERE
        
        
        double[] basket = new double[7];
        basket[0] = inch;
        basket[1] = yard;
        basket[2] = mile;
        basket[3] = centimeter;
        basket[4] = meter;
        basket[5] = kilometer;
        basket[6] = lightYear;
        return basket;
    }
    
    public static void main(String[] args)
    {
        double[] result = unitConversions();
        for (double item : result)
        {
            System.out.println(item);
        }
        
    }
}