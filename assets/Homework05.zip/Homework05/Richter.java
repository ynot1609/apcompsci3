public class Richter
{
    public static String damageReport(double magnitude)
    {
        String damage = "";
        // YOUR CODE HERE
        
        
        return damage;
    }
    
    public static void main(String[] args)
    {
        System.out.println(damageReport(8.7));
        System.out.println(damageReport(7.6));
        System.out.println(damageReport(6.5));
        System.out.println(damageReport(5.4));
        System.out.println(damageReport(4.3));
        System.out.println(damageReport(2.2));
        System.out.println(damageReport(-1.1));
    }
}
