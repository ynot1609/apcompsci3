import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class RichterJUnitTest
{
    @Test
    public void testOne()
    {
        String expected = "This number is not valid";
        String actual = Richter.damageReport(-1.1);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testTwo()
    {
        String expected = "Generally not felt by people";
        String actual = Richter.damageReport(2.2);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testThree()
    {
        String expected = "Felt by many people, no destruction";
        String actual = Richter.damageReport(4.3);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testFour()
    {
        String expected = "Damage to poorly constructed buildings";
        String actual = Richter.damageReport(5.4);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testFive()
    {
        String expected = "Many buildings considerably damaged; some collapse";
        String actual = Richter.damageReport(6.5);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testSix()
    {
        String expected = "Most buildings destroyed";
        String actual = Richter.damageReport(7.6);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testSeven()
    {
        String expected = "Most structures fall";
        String actual = Richter.damageReport(8.7);
        assertEquals(expected, actual);
    }
}