import java.util.*;

public class ClimbingClub
{
    private ArrayList<ClimbInfo> climbList;

    public ClimbingClub()
    {
        climbList = new ArrayList<ClimbInfo>();
    }

    public void addClimbParta(String peakName, int climbTime)
    {
        // YOUR CODE HERE
        
    }

    public void addClimbPartb(String peakName, int climbTime)
    {
        // YOUR CODE HERE
        
    }

    public int distinctPeakNames()
    {
        return 0;
    }

    public String toString()
    {
        String result = "";
        for (ClimbInfo item : climbList)
        {
            result += item.getName() + " " + item.getTime() + "\n";
        }
        return result;
    }
}
