public class ClimbingClubTest
{
    public static void main(String[] args)
    {
        ClimbingClub hikerClub = new ClimbingClub();
        hikerClub.addClimbParta("Monadnock", 274);
        hikerClub.addClimbParta("Whiteface", 301);
        hikerClub.addClimbParta("Algonquin", 225);
        hikerClub.addClimbParta("Monadnock", 344);
        System.out.println(hikerClub);
        
        ClimbingClub mountainClub = new ClimbingClub();
        mountainClub.addClimbPartb("Monadnock", 274);
        mountainClub.addClimbPartb("Whiteface", 301);
        mountainClub.addClimbPartb("Algonquin", 225);
        mountainClub.addClimbPartb("Monadnock", 344);
        mountainClub.addClimbPartb("Quartzface", 297);
        System.out.println(mountainClub);

    }
}
