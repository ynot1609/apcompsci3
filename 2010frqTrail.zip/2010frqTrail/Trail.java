public class Trail
{
    private int[] markers;

    public Trail()
    {
        markers = new int[] {100,150,105,120,90,80,50,75,75,70,80,90,100};
    }

    // Determines if a trail segment is level.
    public boolean isLevelTrailSegment(int start, int end)
    {
        // YOUR CODE HERE
        
    }
    
    public boolean isDifficult()
    {
        // YOUR CODE HERE
        
    }
}


