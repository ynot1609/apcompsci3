public class NumberCube
{
	/** @return an integer value between 1 and 6, inclusive
	*/
	public int toss()
	{ 
	   return (int)(Math.random() * 6 + 1);
	}
	
	// There may be instance variables, constructors, and methods that are not shown.
	
}