public class NumberRunsTest
{
    public static void main(String[] args)
    {
        NumberRuns app = new NumberRuns();
        
        int[] toss1 = app.getCubeTosses(new NumberCube(), 17);
        app.print(toss1);
        
        int[] toss2 = app.getCubeTosses(new NumberCube(), 17);
        app.print(toss2);
        
        int[] toss3 = app.getCubeTosses(new NumberCube(), 17);
        app.print(toss3);
        
        int[] toss4 = {1,3,2,4,6,5,1,3,2,4,6,5,1,3,2,4};
        app.print(toss4);
    }
}