import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class MarathonJUnitTest
{
    @Test
    public void evaluateMinOne()
    {
        int expected = 8;
        int[] times = {341, 273, 278, 329, 445, 402, 388, 275, 243, 334, 412,
        393, 299, 343, 317, 265};
        int actual = Marathon.calculateMin(times);
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateMinTwo()
    {
        int expected = 12;
        int[] times = {209,750,943,265,943,289,832,598,324,650,294,380,134,975,695};
        int actual = Marathon.calculateMin(times);
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateMinThree()
    {
        int expected = 9;
        int[] times = {8347,6502,3498,6520,3499,6523,9486,5243,9865,2349,8652,9843};
        int actual = Marathon.calculateMin(times);
        assertEquals(expected, actual);
    }
}