public class Marathon
{
    public static int calculateMin(int[] arr)
    {
        // YOUR CODE HERE
        
    }
    
    public static void main(String[] args)
    {
        String[] names = {"Elaine", "Thomas", "Hamilton", "Suzie", "Chad", "Matt",
        "Albert", "Ezra", "Jerry", "James", "Jane", "Emily", "Daniel", "Neda",
        "Aaron", "Kate"};

        int[] times = {341, 273, 278, 329, 445, 402, 388, 275, 243, 334, 412,
        393, 299, 343, 317, 265};

        int minIndex = 0;
        minIndex = calculateMin(times);
        System.out.println(names[minIndex] + " " + times[minIndex]);
    }
}