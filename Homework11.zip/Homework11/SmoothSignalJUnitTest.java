import static org.junit.Assert.assertArrayEquals;
import org.junit.Test;

public class SmoothSignalJUnitTest
{
    @Test
    public void evaluateSmoothOne()
    {
        int[] expected = {3, 3, 4, 5, 6, 7, 6, 6, 5, 4, 4, 4};
        int[] waveform = {1, 5, 4, 5, 7, 6, 8, 6, 5, 4, 5, 4};
        int[] actual = SmoothSignal.levelling(waveform);
        assertArrayEquals(expected, actual);
    }
    
    @Test
    public void evaluateSmoothTwo()
    {
        int[] expected = {33,38,48,63,58,63,68,72,72,46,44,35,46,64,77,67,51,42,64,63,65,29};
        int[] waveform = {29,38,47,59,84,32,75,98,43,75,20,39,47,53,94,86,23,46,59,87,43,65};
        int[] actual = SmoothSignal.levelling(waveform);
        assertArrayEquals(expected, actual);
    }

    @Test
    public void evaluateSmoothThree()
    {
        int[] expected = {571,580,415,561,691,691,655,617,582,529,482,464,604,604,703,688,615};
        int[] waveform = {817,326,598,321,765,987,321,659,873,216,498,732,164,918,732,459,873};
        int[] actual = SmoothSignal.levelling(waveform);
        assertArrayEquals(expected, actual);
    }
}
