public class SmoothSignal
{
    public static int[] levelling(int[] audio)
    {
        // YOUR CODE HERE
        
    }
    
    public static void main(String[] args)
    {
        int[] signal = {1, 5, 4, 5, 7, 6, 8, 6, 5, 4, 5, 4};
        int[] smooth;
        
        // compute the smoothed value for each cell of the array smooth
        smooth = levelling(signal);
        
        // display the array signal
        System.out.print("signal: ");
        for (int item : signal)
            System.out.print(item + " ");
        System.out.println();
        
        // display the array smooth
        System.out.print("smooth: ");
        for (int item : smooth)
            System.out.print(item + " ");
        System.out.println();
    }
}
