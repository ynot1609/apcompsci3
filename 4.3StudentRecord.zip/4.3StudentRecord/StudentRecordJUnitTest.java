import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

public class StudentRecordJUnitTest
{
    int[] scores1 = {50, 50, 20, 80, 53}; 
    StudentRecord student1 = new StudentRecord(scores1);
    
    int[] scores2= {20, 50, 50, 53, 80}; 
    StudentRecord student2 = new StudentRecord(scores2);
    
    @Test
    public void evaluateOneAverage()
    {
        double expected = 50.6;
        double actual = student1.average(0, scores1.length-1);
        assertEquals(expected, actual, 0.01);
    }

    @Test
    public void evaluateTwoHasImproved()
    {
        boolean actual = student1.hasImproved();
        assertFalse(actual);
    }
    
    @Test
    public void evaluateThreeFinalAverage()
    {
        double expected = 50.6;
        double actual = student1.finalAverage();
        assertEquals(expected, actual, 0.01);
    }
    
    @Test
    public void evaluateFourAverage()
    {
        double expected = 50.6;
        double actual = student2.average(0, scores2.length-1);
        assertEquals(expected, actual, 0.01);
    }

    @Test
    public void evaluateFiveHasImproved()
    {
        boolean actual = student2.hasImproved();
        assertTrue(actual);
    }
    
    @Test
    public void evaluateSixFinalAverage()
    {
        double expected = 61.0;
        double actual = student2.finalAverage();
        assertEquals(expected, actual, 0.01);
    }
    
}
