public class BankAccountTest
{
    public static void main(String[] args)
    {
        BankAccount myAccount = new BankAccount(1000.0, "Sally");
        System.out.println("Initial balance: " + myAccount.getBalance());
        myAccount.deposit(505.22);
        System.out.println("After deposit: " + myAccount.getBalance());
        myAccount.withdraw(100.0);
        System.out.println("After withdraw: " + myAccount.getBalance());
    
    
    
    
    
    }
}