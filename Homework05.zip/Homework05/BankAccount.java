public class BankAccount
{
    // YOUR CODE HERE
    
}