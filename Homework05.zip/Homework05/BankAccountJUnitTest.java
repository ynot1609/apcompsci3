import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class BankAccountJUnitTest
{
    @Test
    public void evaluatesExpression()
    {
        BankAccount myAccount = new BankAccount(1000.0, "Sally");
        
        double expected = 1000.0;
        double actual = myAccount.getBalance();
        assertEquals(expected, actual, 0.0);
        
        myAccount.deposit(505.22);
        expected = 1505.22;
        actual = myAccount.getBalance();
        assertEquals(expected, actual, 0.0);
        
        myAccount.withdraw(100.0);
        expected = 1405.22;
        actual = myAccount.getBalance();
        assertEquals(expected, actual, 0.0);
    }
}
