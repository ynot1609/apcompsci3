public class AcidLevels
{
    public static double accurateAverage(double[] samples)
    {
        // YOUR CODE HERE
        
    }
    
    public static void main(String[] args)
    {
        double refinedMean = 0.0;
        double litmus[] = {5.6, 6.2, 6.0, 5.5, 5.7, 6.1, 7.4, 5.5, 5.5, 6.3, 6.4, 4.0, 6.9};

        // Calculate new average, excluding maximum outlier
        refinedMean = accurateAverage(litmus);
        System.out.println("Average, excluding maximum outlier: " + refinedMean);
    }
}
