import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class SumEvensJUnitTest
{
    @Test
    public void evaluateSumOne()
    {
        int expected = 92;
        int[] values = {3, 2, 5, 7, 9, 12, 97, 24, 54};
        int actual = SumEvens.calculateSum(values);
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateSumTwo()
    {
        int expected = 274;
        int[] values = {93,84,75,93,48,79,87,59,84,37,59,43,85,20,49,38,75};
        int actual = SumEvens.calculateSum(values);
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateSumThree()
    {
        int expected = 4430;
        int[] values = {924,303,187,659,874,318,348,701,384,765,801,328,746,508};
        int actual = SumEvens.calculateSum(values);
        assertEquals(expected, actual);
    }
}