public class SumEvens
{
    public static int calculateSum(int[] arr)
    {
        // YOUR CODE HERE
        
    }
    
    public static void main(String[] args)
    {
        int[] numbers = {3, 2, 5, 7, 9, 12, 97, 24, 54};
        int result = 0;
        result = calculateSum(numbers);
        System.out.println(result);
    }
}