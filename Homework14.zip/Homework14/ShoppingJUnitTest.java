import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class ShoppingJUnitTest
{
    Sale garmet = new Sale("shirt", 3, 20.0, 0.2);
    Sale slacks = new Sale("pants", 1, 20.0, 0.4);
    
    @Test
    public void evaluateOneGarmet()
    {
        double expected = 51.96;
        double actual = garmet.getTotal();
        assertEquals(expected, actual, 0.01);
    }
    
    @Test
    public void evaluateTwoSlacks()
    {
        double expected = 12.99;
        double actual = slacks.getTotal();
        assertEquals(expected, actual, 0.01);
    }
}
