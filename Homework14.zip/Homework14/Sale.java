public class Sale extends Transaction
{
    // instance variables
    private double discount;
    
    // constructors
    public Sale(String description, int numItems, double itemCost, double reduction)
    {
        // YOUR CODE HERE
        
    }
    
    public double discountSavings()
    {
        // YOUR CODE HERE
        
    }
    
    public double getTotal()
    {
        // YOUR CODE HERE
        
    }
    
    public String toString()
    {
        // YOUR CODE HERE
        
    }
}