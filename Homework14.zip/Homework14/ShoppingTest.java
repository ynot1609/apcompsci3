public class ShoppingTest
{
    public static void main(String[] args)
    {
        Transaction sneakers = new Transaction("shoes", 1, 70.0);
        System.out.println(sneakers);
        
        Transaction bathwear = new Transaction("robe", 2, 40.0);
        System.out.println("\n" + bathwear);
        
        Sale garmet = new Sale("shirt", 3, 20.0, 0.2);
        System.out.println("\n" + garmet);
        
        Sale slacks = new Sale("pants", 1, 20.0, 0.4);
        System.out.println("\n" + slacks);
    }
}