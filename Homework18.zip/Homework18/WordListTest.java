public class WordListTest
{
    public static void main(String[] args)
    {
        WordList w = new WordList();
        w.addItem("cat");
        w.addItem("mouse");
        w.addItem("frog");
        w.addItem("dog");
        w.addItem("dog");
        
        System.out.println(w + " " +
           w.numWordsOfLength(4) + " " +
           w.numWordsOfLength(3) + " " +
           w.numWordsOfLength(2));
        
        w.removeWordsOfLength(4);
        System.out.println(w);
        w.removeWordsOfLength(3);
        System.out.println(w);
        w.removeWordsOfLength(2);
        System.out.println(w);
    }
}
