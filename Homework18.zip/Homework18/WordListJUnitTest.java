import static org.junit.Assert.assertEquals;
import org.junit.Test;
import java.util.*;

public class WordListJUnitTest
{
    WordList w = new WordList();
    
    @Test
    public void evaluateOneNumWordsOfLength()
    {
        w.addItem("cat");
        w.addItem("mouse");
        w.addItem("frog");
        w.addItem("dog");
        w.addItem("dog");
        
        int expected = 1;
        int actual = w.numWordsOfLength(4);
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateTwoNumWordsOfLength()
    {
        w.addItem("cat");
        w.addItem("mouse");
        w.addItem("frog");
        w.addItem("dog");
        w.addItem("dog");
        
        int expected = 3;
        int actual = w.numWordsOfLength(3);
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateThreeNumWordsOfLength()
    {
        w.addItem("cat");
        w.addItem("mouse");
        w.addItem("frog");
        w.addItem("dog");
        w.addItem("dog");
        
        int expected = 0;
        int actual = w.numWordsOfLength(2);
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateFourRemoveWordsOfLength()
    {
        ArrayList<String> expected = new ArrayList<String>();
        expected.add("cat");
        expected.add("mouse");
        expected.add("dog");
        expected.add("dog");
        
        w.addItem("cat");
        w.addItem("mouse");
        w.addItem("frog");
        w.addItem("dog");
        w.addItem("dog");
        
        w.removeWordsOfLength(4);
        assertEquals(expected.toString(), w.toString());
    }
    
    @Test
    public void evaluateFiveRemoveWordsOfLength()
    {
        ArrayList<String> expected = new ArrayList<String>();
        expected.add("mouse");
        
        w.addItem("cat");
        w.addItem("mouse");
        w.addItem("dog");
        w.addItem("dog");
        
        w.removeWordsOfLength(3);
        assertEquals(expected.toString(), w.toString());
    }
    
    @Test
    public void evaluateSixRemoveWordsOfLength()
    {
        ArrayList<String> expected = new ArrayList<String>();
        expected.add("mouse");
        
        w.addItem("mouse");
        
        w.removeWordsOfLength(2);
        assertEquals(expected.toString(), w.toString());
    }
}
