import java.util.*;

public class WordList
{
   // instance variables
   private ArrayList <String> myList;

   public WordList()
   { 
      myList = new ArrayList <String>(); 
   }
  
   public void addItem(String word) 
   { 
      myList.add(word);
   }
  
   public String toString() 
   { 
      return myList.toString();
   }

   // Part (a)
   // postcondition: returns the number of words in this
   //                Wordlist that are exactly len letters long.
   public int numWordsOfLength(int len)
   {
       // YOUR CODE HERE
       
   }

   // Part (b)
   // postcondition: all words that are exactly len letter long
   //                have been removed from the WordList,
   //                with the order of remaining words unchanged.

   public void removeWordsOfLength(int len)
   {
       // YOUR CODE HERE
       
   }
}