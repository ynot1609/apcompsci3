//----------------------------------------------------------
// File Name:	MenuItem.java
// Description:	2014 AP Free Response Question 4.
// Programmer:	Alwin Tareen
// Last Edited:	Mar 11, 2015
// OS Platform:	Linux Mint Maya 13, Java SE Development Kit 7
//
// Compilation:	javac MenuItem.java
// Execution:	<non-executable>
//----------------------------------------------------------

public interface MenuItem
{
    String getName();
    double getPrice();
}

