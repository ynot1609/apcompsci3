public class Trio implements MenuItem
{
    // YOUR CODE HERE
    
}
