/*
 * File: CollectNewspaperKarel.java
 * --------------------------------
 *
 * CollectNewspaperKarel walks to the door of its house, picks up the
 * newspaper (represented by a beeper, of course), and then returns
 * to its initial position in the upper left corner of the house.
 */

import kareltherobot.*;

public class CollectNewspaperKarel extends Karel
{

    // Constructor.
    public CollectNewspaperKarel()
    {
        super(4, 3, 0, "worlds/CollectNewspaperKarel.kwld");
    }

    public void run()
    {
        // Write your solution beginning here.  You should also define additional methods
        
    }

}

