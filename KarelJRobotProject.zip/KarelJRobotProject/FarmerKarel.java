/*
 * File: FarmerKarel.java
 * --------------------------------
 *
 * FarmerKarel walks around his farm, and sections off 4 fields
 * by placing beepers in square configurations, as demonstrated
 * in the graphic that depicts the desired result.
 */

import kareltherobot.*;

public class FarmerKarel extends Karel
{

    // Constructor.
    public FarmerKarel()
    {
        super(1, 1, 100, "worlds/FarmerKarel.kwld");
    }

    public void run()
    {
        // Write your solution beginning here. You should also define additional methods
        
    }

}

