import kareltherobot.*; 

public class Karel extends Robot implements Directions {

    //Constructor
    public Karel (int street, int avenue, int beepers, String worldFile)
    {
        super(street, avenue, East, beepers);
        World.readWorld(worldFile);
        World.setVisible(true);
        World.setDelay(20);
        World.showSpeedControl(true);
        World.setupThread(this);
    }   
}

