/** Description: The Library class defines methods to represent each
 *  library, and manage a collection of books.
 */
import java.util.*;

public class Library
{
    private static String hours = "Libraries are open daily from 9am to 5pm.";
    private String address;
    private ArrayList<Book> bookInventory = new ArrayList<Book>();

    public Library(String libraryAddress)
    {
        address = libraryAddress;
    }
    
    // 2 points
    public static String displayOpeningHours()
    {
        // YOUR CODE HERE
        
    }
    
    // 2 points
    public String displayAddress()
    {
        // YOUR CODE HERE
        
    }
    
    // 2 points
    public String addBook(Book novel)
    {
        // YOUR CODE HERE
        
    }
    
    // 10 points
    public String borrowBook(String novelName)
    {
        // YOUR CODE HERE
        
    }

    public String displayAvailableBooks()
    {
        String catalog = "";
        if (bookInventory.isEmpty())
            catalog = "No books in our catalog.";
        else
        {
            for (Book text : bookInventory)
            {
                if (!text.isBorrowed())
                    catalog += text.getTitle() + "\n";
            }
        }
        return catalog;
    }
    
    // 5 points
    public String returnBook(String textName)
    {
        // YOUR CODE HERE
        
    }
}
