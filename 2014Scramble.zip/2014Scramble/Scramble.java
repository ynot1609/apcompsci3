import java.util.*;

public class Scramble
{
    public static String scrambleWord(String word)
    {
        // YOUR CODE HERE
    }

    public static void scrambleOrRemove(List<String> wordList)
    {
        // YOUR CODE HERE
    }

    public static void main(String[] args)
    {
        System.out.println(scrambleWord("TAN"));
        System.out.println(scrambleWord("ABRACADABRA"));
        System.out.println(scrambleWord("WHOA"));
        System.out.println(scrambleWord("AARDVARK"));
        System.out.println(scrambleWord("EGGS"));
        System.out.println(scrambleWord("A"));
        System.out.println(scrambleWord(""));

        List<String> wordGroup = new ArrayList<String>();
        wordGroup.add("TAN");
        wordGroup.add("ABRACADABRA");
        wordGroup.add("WHOA");
        wordGroup.add("APPLE");
        wordGroup.add("EGGS");
        System.out.println(wordGroup);
        scrambleOrRemove(wordGroup);
        System.out.println(wordGroup);
    }
}