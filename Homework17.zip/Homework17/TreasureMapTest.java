public class TreasureMapTest
{
	public static void main(String[] args)
	{
		boolean [][] map = {{false, true, true, false, true, false, true, false, false},
		                    {false, true, false, false, false, false, true, false, false},
		                    {false, true, false, true, true, false, false, true, true},
		                    {true, false, true, false, true, true, false, false, false},
		                    {false, true, false, false, true, false, false, true, false},
		                    {true, false, false, true, false, true, false, false, false}};
		                    
		TreasureMap treasure = new TreasureMap(map);

		// test hasTreasure method
		System.out.println("hasTreasure(0,2) --> " + treasure.hasTreasure(0,2));
		System.out.println("hasTreasure(0,-1) --> " + treasure.hasTreasure(0,-1));
		System.out.println("hasTreasure(2,3) --> " + treasure.hasTreasure(2,3));
		System.out.println("hasTreasure(2,2) --> " + treasure.hasTreasure(2,2));
		System.out.println("hasTreasure(4,9) --> " + treasure.hasTreasure(4,9));
		System.out.println();
		                    
		// test numAdjacent method
		System.out.println("numAdjacent(3,3) --> " + treasure.numAdjacent(3,3));
		System.out.println("numAdjacent(2,4) --> " + treasure.numAdjacent(2,4));
		System.out.println("numAdjacent(4,7) --> " + treasure.numAdjacent(4,7));
		System.out.println();
	}
}