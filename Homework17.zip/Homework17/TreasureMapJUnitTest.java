import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import org.junit.Test;

public class TreasureMapJUnitTest
{
    boolean [][] map = {{false, true, true, false, true, false, true, false, false},
                            {false, true, false, false, false, false, true, false, false},
                            {false, true, false, true, true, false, false, true, true},
                            {true, false, true, false, true, true, false, false, false},
                            {false, true, false, false, true, false, false, true, false},
                            {true, false, false, true, false, true, false, false, false}};
                            
    TreasureMap theMap = new TreasureMap(map);
    
    @Test
    public void evaluateOneHasTreasure()
    {
        boolean actual = theMap.hasTreasure(0, 2);
        assertTrue(actual);
    }
    
    @Test
    public void evaluateTwoHasTreasure()
    {
        boolean actual = theMap.hasTreasure(0, -1);
        assertFalse(actual);
    }
    
    @Test
    public void evaluateThreeHasTreasure()
    {
        boolean actual = theMap.hasTreasure(2, 3);
        assertTrue(actual);
    }
    
    @Test
    public void evaluateFourHasTreasure()
    {
        boolean actual = theMap.hasTreasure(2, 2);
        assertFalse(actual);
    }
    
    @Test
    public void evaluateFiveHasTreasure()
    {
        boolean actual = theMap.hasTreasure(4, 9);
        assertFalse(actual);
    }
    
    @Test
    public void evaluateSixNumAdjacent()
    {
        int expected = 5;
        int actual = theMap.numAdjacent(3, 3);
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateSevenNumAdjacent()
    {
        int expected = 3;
        int actual = theMap.numAdjacent(2, 4);
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateEightNumAdjacent()
    {
        int expected = 0;
        int actual = theMap.numAdjacent(4, 7);
        assertEquals(expected, actual);
    }
}
