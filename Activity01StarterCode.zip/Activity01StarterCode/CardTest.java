/**
 * This is a class that tests the Card class.
 */
public class CardTest {

	/**
	 * The main method in this class checks the Card operations for consistency.
	 *	@param args is not used.
	 */
	public static void main(String[] args) {
		// Note: Student solutions will vary.  The following is an example.

		Card aceClubs = new Card("ace", "clubs", 1);
		Card tenSpades = new Card("10", "spades", 10);
		Card sixHearts = new Card("6", "hearts", 6);

		System.out.println("**** ace of clubs Tests ****");
		System.out.println("  rank: " + aceClubs.rank());
		System.out.println("  suit: " + aceClubs.suit());
		System.out.println("  pointValue: " + aceClubs.pointValue());
		System.out.println("  toString: " + aceClubs.toString());
		System.out.println();

		System.out.println("**** ten of spades Tests ****");
		System.out.println("  rank: " + tenSpades.rank());
		System.out.println("  suit: " + tenSpades.suit());
		System.out.println("  pointValue: " + tenSpades.pointValue());
		System.out.println("  toString: " + tenSpades.toString());
		System.out.println();

		System.out.println("**** six of hearts Tests ****");
		System.out.println("  rank: " + sixHearts.rank());
		System.out.println("  suit: " + sixHearts.suit());
		System.out.println("  pointValue: " + sixHearts.pointValue());
		System.out.println("  toString: " + sixHearts.toString());
		System.out.println();

		System.out.println("**** matches Tests ****");
		System.out.println("  matching: expected [true]: " + aceClubs.matches(aceClubs));
		System.out.println("  not matching: expected [false]: " + aceClubs.matches(tenSpades));
		System.out.println("  not matching: expected [false]: " + tenSpades.matches(sixHearts));
	}
}
