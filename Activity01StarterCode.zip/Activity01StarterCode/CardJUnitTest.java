import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import org.junit.Test;

public class CardJUnitTest
{
    Card aceClubs = new Card("ace", "clubs", 1);
    Card tenSpades = new Card("10", "spades", 10);
    
    @Test
    public void evaluateOneRank()
    {
        String expected = "ace";
        String actual = aceClubs.rank();
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateTwoSuit()
    {
        String expected = "clubs";
        String actual = aceClubs.suit();
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateThreePointValue()
    {
        int expected = 1;
        int actual = aceClubs.pointValue();
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateFourToString()
    {
        String expected = "ace of clubs (point value = 1)";
        String actual = aceClubs.toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateFiveMatches()
    {
        boolean actual = aceClubs.matches(aceClubs);
        assertTrue("FAIL: Result should be [true]", actual);
    }
    
    @Test
    public void evaluateSixMatches()
    {
        boolean actual = aceClubs.matches(tenSpades);
        assertFalse("FAIL: Result should be [false]", actual);
    }
}
