public class Circle implements Shape
{
    // instance variables
    private double radius;
    
    // constructors
    public Circle(double r)
    {
        radius = r;
    }
    
    // abstract methods overridden
    public double getArea()
    {
        return Math.PI * radius * radius;
    }
}