import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class CalculateAreaJUnitTest
{
    Shape rec = new Rectangle(20, 10);
    
    @Test
    public void evaluateOneRectangle()
    {
        double expected = 200.0;
        double actual = rec.getArea();
        assertEquals(expected, actual, 0.01);
    }
}
    