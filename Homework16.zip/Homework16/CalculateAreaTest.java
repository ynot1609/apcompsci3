public class CalculateAreaTest
{
    public static void main(String[] args)
    {
        Shape rec = new Rectangle(20, 10);
        Shape cir = new Circle(5);
        
        System.out.println("Area of Rectangle = " + rec.getArea());
        System.out.println("Area of Circle = " + cir.getArea());
    }
}
