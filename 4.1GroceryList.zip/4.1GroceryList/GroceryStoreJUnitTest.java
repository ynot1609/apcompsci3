import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class GroceryStoreJUnitTest
{
    GroceryStore store = new GroceryStore();
    
    @Test
    public void evaluateOneSetPrice()
    {
        store.setPrice("milk", 1.92);
        double expected = 1.92;
        double actual = store.getPrice("milk");
        assertEquals(expected, actual, 0.01);
    }
    
    @Test
    public void evaluateTwoSetPrice()
    {
        store.setPrice("porkchops", 2.24);
        double expected = 2.24;
        double actual = store.getPrice("porkchops");
        assertEquals(expected, actual, 0.01);
    }
    
    @Test
    public void evaluateThreeBargainItem()
    {
        String expected = "spinach";
        String actual = store.bargainItem("P");
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateFourBargainItem()
    {
        String expected = "porkchops";
        String actual = store.bargainItem("M");
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateFiveBargainItem()
    {
        String expected = "none";
        String actual = store.bargainItem("B");
        assertEquals(expected, actual);
    }
}
