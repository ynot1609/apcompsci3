import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class AutomobileJUnitTest
{
    @Test
    public void evaluatesExpression()
    {
        Automobile honda = new Automobile(25.0, 0.0);
        honda.fillUp(20.0);
        honda.takeTrip(100.0);
        
        double expected = 16.0;
        double actual = honda.displayFuel();
        assertEquals(expected, actual, 0.0);
        
        expected = 400.0;
        actual = honda.maxRange();
        assertEquals(expected, actual, 0.0);
    }
}
