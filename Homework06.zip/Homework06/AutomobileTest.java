public class AutomobileTest
{
    public static void main(String[] args)
    {
        Automobile honda = new Automobile(25.0, 0.0);
        honda.fillUp(20.0);
        honda.takeTrip(100.0);
        double fuelqty = honda.displayFuel();
        System.out.println("Remaining Fuel: " + fuelqty);
        double range = honda.maxRange();
        System.out.println("Maximum Range: " + range);    
    }
}
