public class Automobile
{
    // YOUR CODE HERE
    
}