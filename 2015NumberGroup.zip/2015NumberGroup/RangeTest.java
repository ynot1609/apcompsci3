public class RangeTest
{
    public static void main(String[] args)
    {
        NumberGroup range1 = new Range(-3, 2);
        System.out.println(range1);
    }
}