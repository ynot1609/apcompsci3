public interface NumberGroup
{
    // YOUR CODE HERE
    
}