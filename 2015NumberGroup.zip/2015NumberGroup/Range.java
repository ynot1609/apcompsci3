public class Range implements NumberGroup
{
    // YOUR CODE HERE
    
}
