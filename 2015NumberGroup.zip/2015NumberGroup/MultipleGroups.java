import java.util.*;

public class MultipleGroups implements NumberGroup
{
    // YOUR CODE HERE
    
}