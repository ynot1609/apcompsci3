import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class NameEchoJUnitTest
{
    @Test
    public void capitalizeHolmes()
    {
        String expected = "Sherlock HOLMES";
        String actual = NameEcho.capitalize("Sherlock Holmes");
        assertEquals(expected, actual);
    }
    
    @Test
    public void capitalizeBond()
    {
        String expected = "James BOND";
        String actual = NameEcho.capitalize("James Bond");
        assertEquals(expected, actual);
    }
    
    @Test
    public void capitalizeEverdeen()
    {
        String expected = "Katniss EVERDEEN";
        String actual = NameEcho.capitalize("Katniss Everdeen");
        assertEquals(expected, actual);
    }
    
    @Test
    public void capitalizeSwann()
    {
        String expected = "Elizabeth SWANN";
        String actual = NameEcho.capitalize("Elizabeth Swann");
        assertEquals(expected, actual);
    }
}