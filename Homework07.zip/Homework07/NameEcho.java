public class NameEcho
{
    public static String capitalize(String name)
    {
        // YOUR CODE HERE
        
    }
    
    
    
    public static void main(String[] args)
    {
        String result = "";
        String detective = "Sherlock Holmes";
        result = capitalize(detective);
        System.out.println(result);
        
        String agent = "James Bond";
        result = capitalize(agent);
        System.out.println(result);
    }
}