import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class SumMultiplesJUnitTest
{
    @Test
    public void evaluatesExpression()
    {
        int expected = 233168;
        int actual = SumMultiples.calculateSum();
        assertEquals(expected, actual);
    }
}