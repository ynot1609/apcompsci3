public class SumMultiples
{
    public static int calculateSum()
    {
        // YOUR CODE HERE
        
    }
    
    public static void main(String[] args)
    {
        int result = calculateSum();
        System.out.println(result);
    }
}