public class Sound
{
    private int[] samples;

    public Sound(int[] clips)
    {
        samples = clips;
    }

    public int limitAmplitude(int limit)
    {
        // YOUR CODE HERE
        
    }

    public void trimSilenceFromBeginning()
    {
        // YOUR CODE HERE
        
    }

    public String toString()
    {
        String result = "";
        for (int item : samples)
        {
            result += item + " ";
        }
        return result;
    }
}
