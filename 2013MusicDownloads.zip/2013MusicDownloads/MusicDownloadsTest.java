import java.util.*;

public class MusicDownloadsTest
{
    public static void main(String[] args)
    {
        // Part a
        DownloadInfo hj = new DownloadInfo("Hey Jude");
        hj.setTimesDownloaded(5);
        DownloadInfo ss = new DownloadInfo("Soul Sister");
        ss.setTimesDownloaded(3);
        DownloadInfo aq = new DownloadInfo("Aqualung");
        aq.setTimesDownloaded(10);
        
        MusicDownloads webMusicA = new MusicDownloads();
        webMusicA.addDownloadInfo(hj);
        webMusicA.addDownloadInfo(ss);
        webMusicA.addDownloadInfo(aq);

        System.out.println(webMusicA.getDownloadInfo("Aqualung"));
        System.out.println(webMusicA.getDownloadInfo("Happy Birthday"));

        // Part b
        ArrayList<String> songTitles = new ArrayList<String>();
        songTitles.add("Lights");
        songTitles.add("Aqualung");
        songTitles.add("Soul Sister");
        songTitles.add("Go Now");
        songTitles.add("Lights");
        songTitles.add("Soul Sister");
        
        MusicDownloads webMusicB = new MusicDownloads();
        webMusicB.addDownloadInfo(hj);
        webMusicB.addDownloadInfo(ss);
        webMusicB.addDownloadInfo(aq);

        System.out.println();
        System.out.println("Before:");
        System.out.println(webMusicB);
        webMusicB.updateDownloads(songTitles);
        System.out.println("After:");
        System.out.println(webMusicB);
    }
}
