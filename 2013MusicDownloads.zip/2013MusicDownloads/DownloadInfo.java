public class DownloadInfo
{
    String songTitle;
    int numTimesDownloaded;
    public DownloadInfo(String title)
    {
        songTitle = title;
        numTimesDownloaded = 1;
    }
    public String getTitle()
    {
        return songTitle;
    }
    
    public int getDownloads()
    {
        return numTimesDownloaded;
    }

    public void incrementTimesDownloaded()
    {
        numTimesDownloaded += 1;
    }
    
    public void setTimesDownloaded(int timesDownloaded)
    {
        numTimesDownloaded = timesDownloaded;
    }
       
    public String toString()
    {
        String nameDisplay = "";
        nameDisplay += "Title: " + songTitle + "\n";
        nameDisplay += "Downloads: " + numTimesDownloaded;
        return nameDisplay;
    }
}
